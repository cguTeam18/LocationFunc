/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package locationip3;

import java.net.URL;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

/**
 *
 * @author jorda
 */
public class LocationIP3 extends Application {
    
@Override
    public void start(Stage stage) {
        WebView webView= new WebView();
        WebEngine webEngine = webView.getEngine();
        final URL urlGoogleMaps = getClass().getResource("/HTML/GoogleMapsNew.html");
        webEngine.load(urlGoogleMaps.toExternalForm());
        Scene scene = new Scene(webView,400,600, Color.web("#666970"));
        stage.setScene(scene);
        stage.show();
    }
    
    static {
        System.setProperty("java.net.useSystemProxies", "true");
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Application.launch(args);
    }
    
}
